//
//  LightingApp.swift
//  Lighting
//
//  Created by GH on 11/28/25.
//

import SwiftUI

@main
struct LightingApp: App {
    var body: some Scene {
        WindowGroup {
            MetalView()
        }
    }
}
