//
//  Common.h
//  Lighting
//
//  Created by GH on 11/28/25.
//

#import <simd/simd.h>

typedef struct {
    matrix_float4x4 mvpMatrix;
} Uniforms;
