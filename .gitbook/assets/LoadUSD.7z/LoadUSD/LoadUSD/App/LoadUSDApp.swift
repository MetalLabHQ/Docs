//
//  LoadUSDApp.swift
//  LoadUSD
//
//  Created by GH on 1/5/26.
//

import SwiftUI

@main
struct LoadUSDApp: App {
    var body: some Scene {
        WindowGroup {
            MetalView()
        }
    }
}
