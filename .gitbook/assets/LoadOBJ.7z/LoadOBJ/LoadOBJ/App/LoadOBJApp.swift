//
//  LoadOBJApp.swift
//  LoadOBJ
//
//  Created by GH on 1/5/26.
//

import SwiftUI

@main
struct LoadOBJApp: App {
    var body: some Scene {
        WindowGroup {
            MetalView()
        }
    }
}
