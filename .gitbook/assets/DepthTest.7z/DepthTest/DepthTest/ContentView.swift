//
//  MetalView.swift
//  DepthTest
//
//  Created by GH on 1/5/26.
//

import SwiftUI

struct MetalView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    MetalView()
}
