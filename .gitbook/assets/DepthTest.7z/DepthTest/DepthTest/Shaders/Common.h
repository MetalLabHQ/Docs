//
//  Common.h
//  DepthTest
//
//  Created by GH on 11/3/25.
//

#import <simd/simd.h>

typedef struct {
    matrix_float4x4 mvpMatrix;  // 预计算的 MVP 矩阵
} Uniforms;
