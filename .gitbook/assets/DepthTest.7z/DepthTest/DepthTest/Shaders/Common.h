//
//  Common.h
//  DepthTest
//
//  Created by GH on 1/5/26.
//

#import <simd/simd.h>

typedef struct {
    matrix_float4x4 mvpMatrix;
} Uniforms;
