//
//  LookAt.swift
//  DepthTest
//
//  Created by GH on 11/3/25.
//

import simd

/// 视图矩阵 View Matrix
/// - Parameters:
///   - eye: 相机的位置
///   - center: 相机要看向的目标点
///   - up: 相机的上方向
/// - Returns: 视图矩阵 View Matrix
func lookAt(eye: SIMD3<Float>, center: SIMD3<Float>, up: SIMD3<Float>) -> float4x4 {
    let zAxis = normalize(center - eye)
    
    let xAxis = normalize(cross(up, zAxis))
    
    let yAxis = cross(zAxis, xAxis)
    
    return float4x4(
        SIMD4<Float>( xAxis.x, yAxis.x, zAxis.x, 0),
        SIMD4<Float>( xAxis.y, yAxis.y, zAxis.y, 0),
        SIMD4<Float>( xAxis.z, yAxis.z, zAxis.z, 0),
        SIMD4<Float>(-dot(xAxis, eye), -dot(yAxis, eye), -dot(zAxis, eye), 1)
    )
}
