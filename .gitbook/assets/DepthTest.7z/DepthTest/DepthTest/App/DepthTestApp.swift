//
//  DepthTestApp.swift
//  DepthTest
//
//  Created by GH on 1/5/26.
//

import SwiftUI

@main
struct DepthTestApp: App {
    var body: some Scene {
        WindowGroup {
            MetalView()
        }
    }
}
