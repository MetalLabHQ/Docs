//
//  DepthTestApp.swift
//  DepthTest
//
//  Created by GH on 11/3/25.
//

import SwiftUI

@main
struct DepthTestApp: App {
    var body: some Scene {
        WindowGroup {
            MetalView()
        }
    }
}
