//
//  MetalView.swift
//  LoadAssets
//
//  Created by GH on 11/9/25.
//

import SwiftUI

struct MetalView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    MetalView()
}
