//
//  LookAt.swift
//  LoadAssets
//
//  Created by GH on 11/9/25.
//

import simd

/// 视图矩阵 View Matrix
/// - Parameters:
///   - eye: 相机位置
///   - target: 目标点
///   - up: 参考上方向向量
func lookAt(eye: SIMD3<Float>, target: SIMD3<Float>, up: SIMD3<Float>) -> float4x4 {
    let forward = normalize(target - eye)
    let right = normalize(cross(forward, up))
    let upCorrected = cross(right, forward)
    
    let X = SIMD4<Float>(right.x, right.y, right.z, 0)
    let Y = SIMD4<Float>(upCorrected.x, upCorrected.y, upCorrected.z, 0)
    let Z = SIMD4<Float>(-forward.x, -forward.y, -forward.z, 0)
    let W = SIMD4<Float>(-dot(right, eye), -dot(upCorrected, eye), dot(forward, eye), 1)
    
    return float4x4(X, Y, Z, W)
}
