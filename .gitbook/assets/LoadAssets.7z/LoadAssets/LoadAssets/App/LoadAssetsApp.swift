//
//  LoadAssetsApp.swift
//  LoadAssets
//
//  Created by GH on 11/9/25.
//

import SwiftUI

@main
struct LoadAssetsApp: App {
    var body: some Scene {
        WindowGroup {
            MetalView()
        }
    }
}
