//
//  HelloMetalViewApp.swift
//  HelloMetalView
//
//  Created by GH on 10/26/25.
//

import SwiftUI

@main
struct HelloMetalViewApp: App {
    var body: some Scene {
        WindowGroup {
            MetalView()
        }
    }
}
