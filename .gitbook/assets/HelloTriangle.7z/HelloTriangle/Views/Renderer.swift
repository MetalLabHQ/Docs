//
//  Renderer.swift
//  HelloTriangle
//
//  Created by GH on 10/26/25.
//

import SwiftUI
import MetalKit

class Renderer: NSObject, MTKViewDelegate {
    let device: MTLDevice                           // GPU 设备
    
    // MARK: - Command Queue
    let commandQueue: MTL4CommandQueue              // 命令队列
    let commandBuffer: MTL4CommandBuffer            // Metal 命令 Buffer
    let commandAllocator: MTL4CommandAllocator      // 命令分配器
    
    init(device: MTLDevice) throws {
        self.device = device
        
        // MARK: - 配置命令队列 Command Queue
        self.commandQueue = device.makeMTL4CommandQueue()!
        self.commandBuffer = device.makeCommandBuffer()!
        self.commandAllocator = device.makeCommandAllocator()!
        
        super.init()
    }
    
    func draw(in view: MTKView) {
        guard let drawable = view.currentDrawable else { return }
        
        // MARK: - 开始命令编码 Begin Command Buffer
        self.commandQueue.waitForDrawable(drawable)
        self.commandAllocator.reset()
        self.commandBuffer.beginCommandBuffer(allocator: commandAllocator)
        
        
        // MARK: - Render Pass
        let mtl4RenderPassDescriptor = MTL4RenderPassDescriptor()
        mtl4RenderPassDescriptor.colorAttachments[0].texture = drawable.texture
        mtl4RenderPassDescriptor.colorAttachments[0].loadAction = .clear
        mtl4RenderPassDescriptor.colorAttachments[0].clearColor  = MTLClearColor(red: 0.2, green: 0.2, blue: 0.25, alpha: 1.0)
        
        
        // MARK: - 开始编码渲染 Begin Render Encoder
        guard let renderEncoder = commandBuffer.makeRenderCommandEncoder(
            descriptor: mtl4RenderPassDescriptor,
            options: MTL4RenderEncoderOptions()
        ) else { return }
        
        
        // MARK: - 结束渲染编码 End Render Encoder
        renderEncoder.endEncoding()
        
        
        // MARK: - 结束命令编码 End Command Buffer
        self.commandBuffer.endCommandBuffer()
        self.commandQueue.commit([commandBuffer], options: nil)
        self.commandQueue.signalDrawable(drawable)
        drawable.present()
    }
    
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}
}

#Preview {
    MetalView()
}
