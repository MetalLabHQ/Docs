//
//  Vertex.swift
//  HelloTriangle
//
//  Created by GH on 10/26/25.
//

import simd

struct Vertex {
    let position: SIMD3<Float>
    let color: SIMD4<Float>
}

let vertices: [Vertex] = [
    Vertex(position: SIMD3<Float>(0.0,  0.5, 0.0), color: SIMD4<Float>(1.0, 0.0, 0.0, 1.0)),   // 顶点 1 (红色)
    Vertex(position: SIMD3<Float>(-0.5, -0.5, 0.0), color: SIMD4<Float>(0.0, 1.0, 0.0, 1.0)),  // 顶点 2 (绿色)
    Vertex(position: SIMD3<Float>(0.5, -0.5, 0.0), color: SIMD4<Float>(0.0, 0.0, 1.0, 1.0))    // 顶点 3 (蓝色)
]
