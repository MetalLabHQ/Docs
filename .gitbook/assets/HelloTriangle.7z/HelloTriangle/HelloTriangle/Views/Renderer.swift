//
//  Renderer.swift
//  HelloTriangle
//
//  Created by GH on 10/26/25.
//

import SwiftUI
import MetalKit

class Renderer: NSObject, MTKViewDelegate {
    let device: MTLDevice                           // GPU 设备
    let commandQueue: MTL4CommandQueue              // 命令队列
    let commandBuffer: MTL4CommandBuffer            // Metal 命令 Buffer
    let commandAllocator: MTL4CommandAllocator      // 命令分配器
    let pipelineState: MTLRenderPipelineState       // 渲染管线状态
    let vertexBuffer: MTLBuffer                     // 顶点缓冲区
    let vertexArgumentTable: MTL4ArgumentTable      // 顶点着色器参数表
    
    init(device: MTLDevice) throws {
        // MARK: - 配置队列
        self.device = device
        self.commandQueue = device.makeMTL4CommandQueue()!
        self.commandBuffer = device.makeCommandBuffer()!
        self.commandAllocator = device.makeCommandAllocator()!
        
        
        // MARK: - 描述内存布局
        let vertexDescriptor = MTLVertexDescriptor()
        // 配置 position 属性
        vertexDescriptor.attributes[0].format = .float3 // 数据类型：3 个浮点数
        vertexDescriptor.attributes[0].offset = 0 // position 的偏移量是 0
        vertexDescriptor.attributes[0].bufferIndex = 0 // 从第 0 个缓冲区读取数据
        
        // 配置 color 属性
        vertexDescriptor.attributes[1].format = .float4 // 数据类型：4 个浮点数
        vertexDescriptor.attributes[1].offset = MemoryLayout<SIMD3<Float>>.stride // 偏移量是 16 字节
        vertexDescriptor.attributes[1].bufferIndex = 0 // 也从第 0 个缓冲区读取数据
        
        // 定义顶点内存布局
        vertexDescriptor.layouts[0].stride = MemoryLayout<Vertex>.stride // 32 字节
        // vertexDescriptor.layouts[0].stepRate = 1                         // 步频为 1，不跳过任何顶点
        // vertexDescriptor.layouts[0].stepFunction = .perVertex            // 逐顶点处理
        
        
        // MARK: - 设置参数表与 Buffer
        // 使用三角形的顶点数组创建 Buffer
        self.vertexBuffer = device.makeBuffer(bytes: vertices, length: vertices.count * MemoryLayout<Vertex>.stride, options: [])!
        
        let argTableDescriptor = MTL4ArgumentTableDescriptor()
        argTableDescriptor.maxBufferBindCount = 1 // 最多可以绑定一个 Buffer
        self.vertexArgumentTable = try device.makeArgumentTable(descriptor: argTableDescriptor)
        vertexArgumentTable.setAddress(vertexBuffer.gpuAddress, index: 0)
        
        
        // MARK: - 加载 Shader
        let library = device.makeDefaultLibrary()!
        
        // 顶点着色器
        let vertexFunctionDescriptor       = MTL4LibraryFunctionDescriptor()
        vertexFunctionDescriptor.library   = library
        vertexFunctionDescriptor.name      = "vertex_main"
        
        // 片元着色器
        let fragmentFunctionDescriptor     = MTL4LibraryFunctionDescriptor()
        fragmentFunctionDescriptor.library = library
        fragmentFunctionDescriptor.name    = "fragment_main"
        
        
        // MARK: - 渲染管线描述符
        let pipelineDescriptor = MTL4RenderPipelineDescriptor()
        pipelineDescriptor.vertexFunctionDescriptor        = vertexFunctionDescriptor
        pipelineDescriptor.fragmentFunctionDescriptor      = fragmentFunctionDescriptor
        pipelineDescriptor.vertexDescriptor                = vertexDescriptor
        pipelineDescriptor.colorAttachments[0].pixelFormat = .bgra8Unorm
//        pipelineDescriptor.inputPrimitiveTopology          = .triangle
        
        // 创建渲染管线状态
        self.pipelineState = try device
            .makeCompiler(descriptor: MTL4CompilerDescriptor())
            .makeRenderPipelineState(descriptor: pipelineDescriptor)
        
        super.init()
    }
    
    func draw(in view: MTKView) {
        guard let drawable = view.currentDrawable else { return }
        
        commandQueue.waitForDrawable(drawable)
        commandAllocator.reset()
        
        commandBuffer.beginCommandBuffer(allocator: commandAllocator)
        
        let mtl4RenderPassDescriptor = MTL4RenderPassDescriptor()
        mtl4RenderPassDescriptor.colorAttachments[0].texture = drawable.texture
        mtl4RenderPassDescriptor.colorAttachments[0].loadAction = .clear
        mtl4RenderPassDescriptor.colorAttachments[0].clearColor  = MTLClearColor(red: 0.2, green: 0.2, blue: 0.25, alpha: 1.0)
        
        guard let renderEncoder = commandBuffer.makeRenderCommandEncoder(
            descriptor: mtl4RenderPassDescriptor,
            options: MTL4RenderEncoderOptions()
        ) else { return }
        
        
        // MARK: - 设置渲染状态
        renderEncoder.setRenderPipelineState(pipelineState)
        renderEncoder.setArgumentTable(vertexArgumentTable, stages: .vertex)
        
        
        // MARK: - 绘制
        renderEncoder.drawPrimitives(
            primitiveType: .triangle,
            vertexStart: 0,
            vertexCount: vertices.count
        )
        
        
        renderEncoder.endEncoding()
        
        commandBuffer.endCommandBuffer()
        commandQueue.commit([commandBuffer], options: nil)
        commandQueue.signalDrawable(drawable)
        drawable.present()
    }
    
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}
}

#Preview {
    MetalView()
}
