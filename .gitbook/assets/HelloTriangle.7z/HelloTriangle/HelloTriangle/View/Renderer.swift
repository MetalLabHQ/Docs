//
//  Renderer.swift
//  HelloTriangle
//
//  Created by GH on 10/26/25.
//

import SwiftUI
import MetalKit

class Renderer: NSObject, MTKViewDelegate {
    let device: MTLDevice                           // GPU 设备
    let commandQueue: MTL4CommandQueue              // 命令队列
    let commandBuffer: MTL4CommandBuffer            // Metal 命令 Buffer
    let commandAllocator: MTL4CommandAllocator      // 命令分配器

    init(device: MTLDevice) throws {
        self.device = device
        self.commandQueue = device.makeMTL4CommandQueue()!
        self.commandBuffer = device.makeCommandBuffer()!
        self.commandAllocator = device.makeCommandAllocator()!
        
        super.init()
    }
    
    func draw(in view: MTKView) {
        guard let drawable = view.currentDrawable else { return }
        
        commandQueue.waitForDrawable(drawable)
        commandAllocator.reset()
        
        commandBuffer.beginCommandBuffer(allocator: commandAllocator)
        
        let mtl4RenderPassDescriptor = MTL4RenderPassDescriptor()
        mtl4RenderPassDescriptor.colorAttachments[0].texture = drawable.texture
        mtl4RenderPassDescriptor.colorAttachments[0].loadAction = .clear
        mtl4RenderPassDescriptor.colorAttachments[0].clearColor  = MTLClearColor(red: 0.2, green: 0.2, blue: 0.25, alpha: 1.0)
        
        guard let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: mtl4RenderPassDescriptor, options: MTL4RenderEncoderOptions()) else { return }
        
        renderEncoder.endEncoding()
        commandBuffer.endCommandBuffer()
        commandQueue.commit([commandBuffer], options: nil)
        commandQueue.signalDrawable(drawable)
        drawable.present()
    }
    
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        
    }
}

#Preview {
    MetalView()
}
