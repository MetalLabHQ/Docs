//
//  HelloTriangleApp.swift
//  HelloTriangle
//
//  Created by GH on 10/26/25.
//

import SwiftUI

@main
struct HelloTriangleApp: App {
    var body: some Scene {
        WindowGroup {
            MetalView()
        }
    }
}
