//
//  HelloCubeApp.swift
//  HelloCube
//
//  Created by GH on 10/28/25.
//

import SwiftUI

@main
struct HelloCubeApp: App {
    var body: some Scene {
        WindowGroup {
            MetalView()
        }
    }
}
